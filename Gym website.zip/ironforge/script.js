// Mobile menu toggle
const toggle = document.getElementById('menuToggle');
const menu = document.getElementById('mobileMenu');
toggle.addEventListener('click', () => {
  menu.classList.toggle('open');
  const icon = menu.classList.contains('open') ? 'x' : 'menu';
  toggle.innerHTML = `<i data-lucide="${icon}"></i>`;
  if (window.lucide) window.lucide.createIcons();
});

// Close mobile menu on link click
menu.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('open');
    toggle.innerHTML = '<i data-lucide="menu"></i>';
    if (window.lucide) window.lucide.createIcons();
  });
});

// Init lucide icons after DOM
window.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) window.lucide.createIcons();
});
